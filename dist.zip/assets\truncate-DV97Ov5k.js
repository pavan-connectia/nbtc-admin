const e=(t,c)=>t.length<c?t:t.slice(0,c)+"...";export{e as t};
