import{j as t}from"./index-KJlODoIt.js";const n=({variant:o="sm"})=>{const s={sm:"w-32 h-12"};return t.jsx("img",{src:"/logo.png",alt:"logo",className:`object-contain ${s[o]}`})};export{n as L};
