import{j as a,ap as n}from"./index-KJlODoIt.js";const m=({as:t="p",children:s,className:e,...o})=>{const r=t;return a.jsx(r,{...o,className:n("text-muted-foreground",e),children:s})};export{m as T};
